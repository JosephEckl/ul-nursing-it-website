﻿/* Provides a separtate variable for bootstrap jquery */

var jqbs = jQuery.noConflict();

/* This is a replacement for the text area widget helper js textcount.js that's delivered by Products.Archetypes.  This should be compatible with JQuery 1.6+ and leave the alert in for accessibilty purposes */

function textCounter(field, countfield, maxlimit) {
  var fieldval = jqbs(field).val();
  var counterElem = jqbs('input[name="' + countfield + '"]');
  if (fieldval.length > maxlimit) {
    // if too long...trim it!
        jqbs(field).val(fieldval.substring(0, maxlimit));
        counterElem.css('border-color', 'red');
        alert( 'This field is limited to ' + maxlimit + ' characters in length.' );
    } else {
        counterElem.css('border-color', '#ccc');
    }
    // update 'characters left' counter
    counterElem.val(Math.max(maxlimit - fieldval.length, 0));
}
